insert into Employee (id,name,gender,age,salary) values(1,'Manu','male',23,45000);
insert into Employee (id,name,gender,age,salary) values(2,'Suma','female',21,56000);
insert into Employee (id,name,gender,age,salary)  values(3,'Shivani','female',24,76000);
insert into Employee (id,name,gender,age,salary) values(4,'John','male',34,99000);
