package com.dynamobackend.demodynamobackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemodynamobackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
